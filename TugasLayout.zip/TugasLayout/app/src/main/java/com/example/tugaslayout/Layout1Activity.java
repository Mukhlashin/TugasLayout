package com.example.tugaslayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Layout1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout1);
    }
}
